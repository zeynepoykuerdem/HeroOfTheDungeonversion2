import java.util.ArrayList;
import java.util.Random;

public abstract class Hero extends Character implements Battle{
    private Weapon weapon;
    private Armor armor;
    private int movableWeight;
    private ArrayList<Item> Inventory;


    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public Armor getArmor() {
        return armor;
    }

    public void setArmor(Armor armor) {
        this.armor = armor;
    }

    public int getMovableWeight() {
        return movableWeight;
    }

    public void setMovableWeight(int movableWeight) {
        this.movableWeight = movableWeight;
    }

    public ArrayList<Item> getInventory() {
        return Inventory;
    }

    public void setInventory(ArrayList<Item> inventory) {
        Inventory = inventory;
    }


    public Hero(String name, int HP, int hitDamage, Weapon weapon, Armor armor, int movableWeight, ArrayList<Item> inventory) {
        super(name, HP, hitDamage);
        this.weapon = weapon;
        this.armor = armor;
        this.movableWeight = movableWeight;
        Inventory = inventory;
    }

    public Hero(Weapon weapon, Armor armor, int movableWeight, ArrayList<Item> inventory) {
        super();
        this.weapon = weapon;
        this.armor = armor;
        this.movableWeight = movableWeight;
        Inventory = inventory;
    }



    @Override
    public void heroAttack(Monster monster) {
        Random random = new Random();
        int randomRange =random.nextInt(10);
        if (randomRange<=getWeapon().getRange()) {
            if (monster.getArmor().getProtectionValue()+monster.getWeapon().getBlockPercentage()<getWeapon().getDamage()+getHitDamage()) {
                System.out.println("Hero is attacking to Monster...");
                System.out.println("The Damage Given by Hero to Monster: " + getHitDamage() + getWeapon().getDamage() * getWeapon().getRange());
                monster.setHP(monster.getHP() + monster.getArmor().getProtectionValue() - getHitDamage() + getWeapon().getDamage() * getWeapon().getRange());
                System.out.println();
            }
            else{
                System.out.println("Monster blocked the attack...");
            }
        }
        else if(randomRange>getWeapon().getRange()){
            System.out.println("The hero missed the attack...");
        }
    }

}
