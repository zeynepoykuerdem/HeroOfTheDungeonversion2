public class Bow extends Weapon {

    public Bow(String name, int weight, int value, int damage, int range, int blockpercentage) {
        super(name, weight, value, damage, range, blockpercentage);
    }

    public Bow() {
        super();
    }

}