public class Axe extends Weapon {

    public Axe(String name, int weight, int value, int damage, int range, int blockpercentage) {
        super(name, weight, value, damage, range, blockpercentage);
    }

    public Axe() {
        super();
    }
}
