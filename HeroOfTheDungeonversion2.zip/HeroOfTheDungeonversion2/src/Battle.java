public interface Battle {

    void heroAttack(Monster monster);
    void monsterAttack(Hero hero);

    String[] swords= {"Dagger","Shortsword","Longsword"};
    int[] swordsDamages = {2,3,4};
    int[] swordsRanges = {1,3,5};
    int[] swordsWeights= {1,2,4};
    int[] swordsWorths= {1,3,5};

    String[] axes={"Smallaxe","Axe","Broad Axe"};
    int[] axesDamages= {1,2,4};
    int[] axesRanges= {1,2,3};
    int[] axesWeights= {1,2,3};
    int[] axesWorths= {1,3,5};

    String[] bows= {"Shortbow","Longbow","Composite Bow"};
    int[] bowsDamages= {3,5,7};
    int[] bowsRanges= {5,7,8};
    int[] bowsWeights= {1,2,3};
    int[] bowsWorths= {1,3,5};

    String[] armors= {"Light Clothing","Leather Armor","Chainmail Armor"};
    int[] armorsProtectionValues= {5,7,9};
    int[] armorsWeights= {1,2,3};
    int[] armorsWorths= {1,3,5};
}


