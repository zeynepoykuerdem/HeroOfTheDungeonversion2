public class Sword extends Weapon {

    public Sword(String name, int weight, int value, int damage, int range, int blockpercentage) {
        super(name, weight, value, damage, range, blockpercentage);
    }

    public Sword() {
        super();
    }


}

